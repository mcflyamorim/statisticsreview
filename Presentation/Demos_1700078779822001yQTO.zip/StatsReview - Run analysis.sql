/*
  There are two options to run the checks.

  1 - Run individual scripts
  2 - Run the PS to create the Excel report.
  C:\>& "D:\Fabiano\Trabalho\WebCasts, Artigos e Palestras\Index and Statistics review\StatisticsReview - Individual checks\ExportStatisticsChecksToExcel.ps1" -SQLInstance "DELLFABIANO\SQL2019" -LogFilePath "C:\temp\" -Force_sp_GetStatisticInfo_Execution -CreateTranscriptLog -ShowVerboseMessages
*/