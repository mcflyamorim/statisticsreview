/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Duplicated stats
*/
USE Northwind
GO

-- Create table
IF OBJECT_ID('TabDuplicatedStats') IS NOT NULL
  DROP TABLE TabDuplicatedStats
GO
CREATE TABLE TabDuplicatedStats (ID Int,
                   Col1 VarChar(200) DEFAULT NEWID(),
                   Col2 VarChar(200) DEFAULT NEWID(),
                   Col3 VarChar(200) DEFAULT NEWID(),
                   Col4 VarChar(200) DEFAULT NEWID(),
                   Col5 VarChar(200) DEFAULT NEWID())
GO

-- 2 seconds to run
INSERT INTO TabDuplicatedStats WITH(TABLOCK)(ID) 
SELECT TOP 2000000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0)
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 4)
GO

-- This will trigger auto create stats for all columns on distinct
SELECT DISTINCT TOP 1 
       Col1,
       Col2,
       Col3,
       Col4,
       Col5 
FROM TabDuplicatedStats
GO
sp_helpstats TabDuplicatedStats
GO

-- 8 seconds to run
-- Create indexes on Cols
CREATE INDEX ixCol1 ON TabDuplicatedStats(Col1)
CREATE INDEX ixCol2 ON TabDuplicatedStats(Col2)
CREATE INDEX ixCol3 ON TabDuplicatedStats(Col3)
CREATE INDEX ixCol4 ON TabDuplicatedStats(Col4)
CREATE INDEX ixCol5 ON TabDuplicatedStats(Col5)
GO

-- Enable TF 8721 to show time spent on update stat
-- 6.5 seconds to run 
DBCC TRACEON(3604, 8721) WITH NO_INFOMSGS
GO
SET STATISTICS TIME, IO ON
UPDATE STATISTICS TabDuplicatedStats WITH FULLSCAN
SET STATISTICS TIME, IO OFF
GO
DBCC TRACEOFF(3604, 8721) WITH NO_INFOMSGS
GO
--STATS: UPDATED Stats: TabDuplicatedStats.._WA_Sys_00000002_4EDDB18F Dbid = 5 Indid = 2 Rows: 2000000 Duration: 641ms
--STATS: UPDATED Stats: TabDuplicatedStats.._WA_Sys_00000003_4EDDB18F Dbid = 5 Indid = 3 Rows: 2000000 Duration: 625ms
--STATS: UPDATED Stats: TabDuplicatedStats.._WA_Sys_00000004_4EDDB18F Dbid = 5 Indid = 4 Rows: 2000000 Duration: 610ms
--STATS: UPDATED Stats: TabDuplicatedStats.._WA_Sys_00000005_4EDDB18F Dbid = 5 Indid = 5 Rows: 2000000 Duration: 609ms
--STATS: UPDATED Stats: TabDuplicatedStats.._WA_Sys_00000006_4EDDB18F Dbid = 5 Indid = 6 Rows: 2000000 Duration: 610ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol1 Dbid = 5 Indid = 7 Rows: 2000000 Duration: 641ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol2 Dbid = 5 Indid = 8 Rows: 2000000 Duration: 641ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol3 Dbid = 5 Indid = 9 Rows: 2000000 Duration: 609ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol4 Dbid = 5 Indid = 10 Rows: 2000000 Duration: 625ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol5 Dbid = 5 Indid = 11 Rows: 2000000 Duration: 594ms
--SQL Server Execution Times:
--  CPU time = 6140 ms,  elapsed time = 6545 ms.

-- Remove duplicated stats
DROP STATISTICS TabDuplicatedStats._WA_Sys_00000002_4EDDB18F
DROP STATISTICS TabDuplicatedStats._WA_Sys_00000003_4EDDB18F
DROP STATISTICS TabDuplicatedStats._WA_Sys_00000004_4EDDB18F
DROP STATISTICS TabDuplicatedStats._WA_Sys_00000005_4EDDB18F
DROP STATISTICS TabDuplicatedStats._WA_Sys_00000006_4EDDB18F
GO

-- Try again
-- 3.1 seconds to run 
DBCC TRACEON(3604, 8721) WITH NO_INFOMSGS
GO
SET STATISTICS TIME, IO ON
UPDATE STATISTICS TabDuplicatedStats WITH FULLSCAN
SET STATISTICS TIME, IO OFF
GO
DBCC TRACEOFF(3604, 8721) WITH NO_INFOMSGS
GO
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol1 Dbid = 5 Indid = 7 Rows: 2000000 Duration: 609ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol2 Dbid = 5 Indid = 8 Rows: 2000000 Duration: 610ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol3 Dbid = 5 Indid = 9 Rows: 2000000 Duration: 609ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol4 Dbid = 5 Indid = 10 Rows: 2000000 Duration: 594ms
--STATS: UPDATED Stats: TabDuplicatedStats..ixCol5 Dbid = 5 Indid = 11 Rows: 2000000 Duration: 610ms
--SQL Server Execution Times:
--  CPU time = 3000 ms,  elapsed time = 3175 ms.