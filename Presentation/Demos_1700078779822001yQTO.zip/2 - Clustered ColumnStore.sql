/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Clustered columnstore index
*/

USE Northwind
GO
IF OBJECT_ID('Customers_CC') IS NOT NULL
  DROP TABLE Customers_CC
GO
SELECT TOP 4995
       ISNULL(CONVERT(INT, ROW_NUMBER() OVER(ORDER BY (SELECT 1))),0) AS CustomerID,
       CONVERT(VARCHAR(250), t4.ColumnToShowIssueWithCCC) AS ColumnToShowIssueWithCCC, 
       CONVERT(VARCHAR(250), t3.ContactName) AS ContactName,
       'Info - ' + ISNULL(CONVERT(VARCHAR(MAX),REPLICATE(CONVERT(VARBINARY(MAX), CONVERT(VARCHAR(250), NEWID())), 1000)), '') AS Info
  INTO Customers_CC
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
 CROSS APPLY (SELECT CRYPT_GEN_RANDOM (10)) AS t1(ContactName)
 CROSS APPLY (SELECT CRYPT_GEN_RANDOM (15)) AS t2(CompanyName)
 CROSS APPLY (SELECT REPLACE(REPLACE(REPLACE(CONVERT(XML, '').value('xs:base64Binary(sql:column("t1.ContactName"))', 'VARCHAR(MAX)'), '=', ''), '/', ''), '+', '')) AS t3(ContactName)
 CROSS APPLY (SELECT REPLACE(REPLACE(REPLACE(CONVERT(XML, '').value('xs:base64Binary(sql:column("t2.CompanyName"))', 'VARCHAR(MAX)'), '=', ''), '/', ''), '+', '')) AS t4(ColumnToShowIssueWithCCC)
OPTION (MAXDOP 4)
GO

DECLARE @Max INT
SELECT @Max = MAX(CustomerID) FROM Customers_CC
INSERT INTO Customers_CC WITH (TABLOCK)
(
    CustomerID,
    ColumnToShowIssueWithCCC,
    ContactName,
    Info
)
SELECT TOP 5
       @Max + ISNULL(CONVERT(INT, ROW_NUMBER() OVER(ORDER BY (SELECT 1))),0) AS CustomerID,
       CONVERT(VARCHAR(250), t4.ColumnToShowIssueWithCCC) AS ColumnToShowIssueWithCCC, 
       CONVERT(VARCHAR(250), 'Fabiano Amorim') AS ContactName,
       'Info - Teste -> *' AS Info
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
 CROSS APPLY (SELECT CRYPT_GEN_RANDOM (10)) AS t1(ContactName)
 CROSS APPLY (SELECT CRYPT_GEN_RANDOM (15)) AS t2(CompanyName)
 CROSS APPLY (SELECT REPLACE(REPLACE(REPLACE(CONVERT(XML, '').value('xs:base64Binary(sql:column("t1.ContactName"))', 'VARCHAR(MAX)'), '=', ''), '/', ''), '+', '')) AS t3(ContactName)
 CROSS APPLY (SELECT REPLACE(REPLACE(REPLACE(CONVERT(XML, '').value('xs:base64Binary(sql:column("t2.CompanyName"))', 'VARCHAR(MAX)'), '=', ''), '/', ''), '+', '')) AS t4(ColumnToShowIssueWithCCC)
OPTION (MAXDOP 4)
GO
CREATE CLUSTERED COLUMNSTORE INDEX ixColumnStore ON Customers_CC
GO
ALTER TABLE Customers_CC ADD CONSTRAINT xpk_Customers_CC PRIMARY KEY NONCLUSTERED(CustomerID)
GO

-- This will trigger auto_create_stats and create
-- a stats on ContactName and on Info columns
-- auto create on column Info will take forever, because 
-- create stats on LOB data is very slow...
SELECT CustomerID, ContactName, Info
  FROM Customers_CC
 WHERE ContactName = 'Fabiano Amorim'
   AND Info LIKE 'Info - Test%'
GO
-- two auto created stats... no modifications
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('Customers_CC');
GO

-- What if I change column ColumnToShowIssueWithCCC that has nothing to do with the existing stats?
UPDATE TOP (5) Customers_CC SET ColumnToShowIssueWithCCC = 'Updated - ' + CONVERT(VARCHAR(250), NEWID())
GO

-- doubled modification increased for all stats...
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('Customers_CC');
GO

-- Auto update treshold for this table is 1500 rows...
-- So, update 750 rows should be enough to hit the target
UPDATE TOP (750) Customers_CC SET ColumnToShowIssueWithCCC = 'Updated - ' + CONVERT(VARCHAR(250), NEWID())
GO

-- 1510 modifications... but none for the columns I've used in the query
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('Customers_CC');
GO

-- Run the query again and see the auto_update 
-- for the stats on columns ContactName and Info
SELECT CustomerID, ContactName, Info
  FROM Customers_CC
 WHERE ContactName = 'Fabiano Amorim'
   AND Info LIKE 'Info - Test%'
GO

-- 0 modifications for ContactName and Info 
-- and last_updated confirming this was recently updated...
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('Customers_CC');
GO