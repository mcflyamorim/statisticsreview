/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Query with OPTION(MAXDOP 1) and CXPACKET waits
*/

USE Northwind
GO
-- Demo 1

-- 15 seconds to run
IF OBJECT_ID('CustomersBig') IS NOT NULL
  DROP TABLE CustomersBig
GO
SELECT TOP 5000000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS CustomerID, 
       SUBSTRING(CONVERT(VARCHAR(250),NEWID()),1,8) AS ContactName, 
       CONVERT(VARCHAR(250), NEWID()) AS Col1,
       CONVERT(VARCHAR(250), NEWID()) AS Col2,
       CONVERT(VARCHAR(250), NEWID()) AS Col3,
       CONVERT(VARCHAR(250), NEWID()) AS Col4,
       CONVERT(VARCHAR(250), NEWID()) AS Col5
  INTO CustomersBig
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 4)
GO
ALTER TABLE CustomersBig ADD CONSTRAINT xpk_CustomersBig PRIMARY KEY(CustomerID)
GO
DROP INDEX IF EXISTS ixContactName ON CustomersBig
CREATE INDEX ixContactName ON CustomersBig(ContactName)
GO
CREATE STATISTICS Stats_Col1 ON CustomersBig(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON CustomersBig(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON CustomersBig(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col4 ON CustomersBig(Col4) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col5 ON CustomersBig(Col5) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
GO
--UPDATE STATISTICS CustomersBig ixContactName WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
--GO

SELECT DISTINCT TOP 100 Col1, Col2, Col3, Col4
FROM CustomersBig
WHERE ContactName LIKE 'AB%'
ORDER BY Col1
OPTION (RECOMPILE, MAXDOP 1)
GO

BEGIN TRAN
TRUNCATE TABLE CustomersBig
ROLLBACK TRAN

-- All rows were modified
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('CustomersBig');
GO

-- This will trigger auto update stats
-- Takes 7 seconds to run...
SELECT DISTINCT TOP 100 Col1, Col2, Col3, Col4
FROM CustomersBig
WHERE ContactName LIKE 'AB%'
ORDER BY Col1
OPTION (RECOMPILE, MAXDOP 1)
GO

-- While is running... Check sp_whoisactive wait info...
/*
-- How can I have a cx* wait in a maxdop 1 query?
exec sp_whoisactive @get_task_info = 2, @get_plans = 1
GO
*/