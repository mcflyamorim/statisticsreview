/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Some comments about default sample ratio
*/
