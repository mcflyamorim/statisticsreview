/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Empty histograms
*/


-- Restore a DB
USE [master]
GO
IF EXISTS (select * from sysdatabases where name='Northwind_SQL2000')
BEGIN
  ALTER DATABASE Northwind_SQL2000 SET SINGLE_USER WITH ROLLBACK IMMEDIATE
		DROP DATABASE Northwind_SQL2000
END
GO
USE [master]
RESTORE DATABASE Northwind_SQL2000 FROM  DISK = N'D:\Fabiano\Trabalho\WebCasts, Artigos e Palestras\PASS Summit 2023\Demos\Northwind_SQL2000_SQL2008_SQL2022.bak' 
WITH  FILE = 1,  
MOVE N'Northwind' TO N'D:\DBs\northwnd_SQL2000.mdf',  
MOVE N'Northwind_log' TO N'D:\DBs\northwnd_SQL2000.ldf',  
NOUNLOAD, STATS = 5
GO

USE Northwind_SQL2000
GO

-- Empty histogram...
DBCC SHOW_STATISTICS ('[Northwind_SQL2000].[dbo].[Orders]',OrderDate)
GO

-- 
SELECT * FROM Orders
WHERE OrderDate >= '19960705'
AND 1 = (SELECT 1)
ORDER BY CustomerID
GO

-- Auto update triggered and stat updated
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('Orders');
GO

DBCC SHOW_STATISTICS ('[Northwind_SQL2000].[dbo].[Orders]',OrderDate)
GO

-- Remember to run update stats after a DB upgrade/migration

/*

Check if there are statistic but no histogram.
This can lead to poor cardinality estimations and weird situations as queries that require the empty statistic,
will show [Columns With No Statistics] warning on execution plans, even with auto create/update statistic enabled.
Statistics that have not been updated since the database was restored or upgraded can have an empty histogram.

- Run DBCC SHOW_STATISTICS command to confirm stat exist and is empty. If a statistic exist with an empty histogram, 
queries using this table will have poor cardinality estimates and show [Columns With No Statistics] warning on execution plans. 
(Note: Warning is only displayed with legacy CE.)
- Remove this statistic, or update it with fullscan or sample.

*/