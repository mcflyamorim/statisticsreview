/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Reduce fullscan update stats duration
*/


-- 1 - Check if all key columns are really required
-- Watch out for auto created multi column stats. Wait, what?

-- Restore a DB
USE [master]
GO
IF EXISTS (select * from sysdatabases where name='Northwind_SQL2000')
BEGIN
  ALTER DATABASE Northwind_SQL2000 SET SINGLE_USER WITH ROLLBACK IMMEDIATE
		DROP DATABASE Northwind_SQL2000
END
GO

--BACKUP DATABASE [Northwind_SQL2000] TO  DISK = N'D:\Fabiano\Trabalho\WebCasts, Artigos e Palestras\PASS Summit 2023\Demos\Northwind_SQL2000_SQL2008_SQL2022.bak' 
--WITH NOFORMAT, NOINIT,  NAME = N'Northwind_SQL2000-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
--GO

USE [master]
RESTORE DATABASE Northwind_SQL2000 FROM  DISK = N'D:\Fabiano\Trabalho\WebCasts, Artigos e Palestras\PASS Summit 2023\Demos\Northwind_SQL2000_SQL2008_SQL2022.bak' 
WITH  FILE = 1,  
MOVE N'Northwind' TO N'D:\DBs\northwnd_SQL2000.mdf',  
MOVE N'Northwind_log' TO N'D:\DBs\northwnd_SQL2000.ldf',  
NOUNLOAD, STATS = 5
GO

USE Northwind_SQL2000
GO

SELECT TOP 100 * FROM OrdersMultiStats
WHERE EmployeeID = 5
GO

EXEC sp_helpstats OrdersMultiStats
GO
EXEC sp_helpindex OrdersMultiStats
GO

DBCC SHOW_STATISTICS(OrdersMultiStats, _WA_Sys_EmployeeID_656C112C)
GO

-- elapsed time = 2509 ms
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats _WA_Sys_EmployeeID_656C112C WITH FULLSCAN
SET STATISTICS IO, TIME OFF
GO
--SQL Server Execution Times:
--  CPU time = 6874 ms,  elapsed time = 2509 ms.

-- elapsed time = 2599 ms
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats WITH SAMPLE
SET STATISTICS IO, TIME OFF
GO
--SQL Server Execution Times:
--  CPU time = 2375 ms,  elapsed time = 2599 ms.

-- elapsed time = 36645 ms
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats WITH FULLSCAN
SET STATISTICS IO, TIME OFF
GO
--SQL Server Execution Times:
-- CPU time = 165415 ms,  elapsed time = 36645 ms.

-- Removing all stats
DROP STATISTICS OrdersMultiStats._WA_Sys_CustomerID_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_EmployeeID_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_Freight_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_OrderDate_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_RequiredDate_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShipAddress_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShipCity_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShipCountry_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShipName_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShippedDate_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShipPostalCode_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShipRegion_656C112C
DROP STATISTICS OrdersMultiStats._WA_Sys_ShipVia_656C112C
GO

-- This will re-create the statistics on columns
SELECT DISTINCT  
       TOP 1 CustomerID, EmployeeID, Freight, OrderDate, RequiredDate, 
             ShipAddress, ShipCity, ShipCountry, ShipName, ShippedDate, 
             ShipPostalCode, ShipRegion, ShipVia 
FROM OrdersMultiStats
WHERE EmployeeID = 5
GO

EXEC sp_helpstats OrdersMultiStats
GO

-- elapsed time = 780 ms.
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats _WA_Sys_00000003_656C112C WITH FULLSCAN
SET STATISTICS IO, TIME OFF
GO
--SQL Server Execution Times:
--  CPU time = 3175 ms,  elapsed time = 780 ms.

-- elapsed time = 1853 ms
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats WITH SAMPLE
SET STATISTICS IO, TIME OFF
GO
--SQL Server Execution Times:
--  CPU time = 1812 ms,  elapsed time = 1853 ms.

-- elapsed time = 22161 ms
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats WITH FULLSCAN
SET STATISTICS IO, TIME OFF
GO
--SQL Server Execution Times:
--  CPU time = 110671 ms,  elapsed time = 22161 ms.


-- 2 - Avoid spilling to tempdb

-- elapsed time = 760 ms.
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats _WA_Sys_00000003_656C112C WITH FULLSCAN
SET STATISTICS IO, TIME OFF
GO
--Memory grant = 310 MB
--SQL Server Execution Times:
--  CPU time = 2951 ms,  elapsed time = 760 ms.

-- TF 7470
-- SQL2014 SP1 CU3 - Released on October 19, 2015 https://support.microsoft.com/kb/3094221
-- SQL2012 SP2 CU8 https://support.microsoft.com/en-us/kb/3082561
-- FIX: Sort operator spills to tempdb in SQL Server 2012 or SQL Server 2014 
-- when estimated number of rows and row size are correct
-- https://support.microsoft.com/en-us/kb/3088480 -- Fix3088480

DBCC TRACEON(7470)
GO
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats _WA_Sys_00000003_656C112C WITH FULLSCAN
SET STATISTICS IO, TIME OFF
--Memory grant = 339 MB
--SQL Server Execution Times:
--  CPU time = 2796 ms,  elapsed time = 760 ms.
GO
DBCC TRACEOFF(7470)
GO

-- Other options
-- Query hint via query store on SQL2022
-- Update stats with WITH ROWCOUNT = <N> and PAGECOUNT = <N>

-- 3 - Adjust MAXDOP to increase available resources
DBCC TRACEON(7470)
GO
SET STATISTICS IO, TIME ON
UPDATE STATISTICS OrdersMultiStats _WA_Sys_00000003_656C112C WITH FULLSCAN, MAXDOP = 16
SET STATISTICS IO, TIME OFF
--Memory grant = 346 MB
--SQL Server Execution Times:
--  CPU time = 3577 ms,  elapsed time = 570 ms.
GO
DBCC TRACEOFF(7470)
GO

-- 4 - Use TF7471 to enable parallel updates
-- Use a parallel statistic maintenance plan that runs multiple 
-- update statistics for different statistics on a single table concurrently.
-- https://support.microsoft.com/en-us/topic/kb3156157-running-multiple-update-statistics-for-different-statistics-on-a-single-table-concurrently-is-available-300f174d-c34d-6635-42f6-db58497cd281
-- CU1 for SQL Server 2016
-- CU6 for SQL Server 2014 SP1