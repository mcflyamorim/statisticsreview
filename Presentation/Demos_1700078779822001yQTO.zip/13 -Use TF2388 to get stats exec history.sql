/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Use TF2388 to get stats exec history
*/

USE Northwind
GO
IF OBJECT_ID('CustomersTF2388') IS NOT NULL
  DROP TABLE CustomersTF2388
GO
SELECT TOP 100000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS CustomerID, 
       SUBSTRING(CONVERT(VARCHAR(250),NEWID()),1,8) AS ContactName, 
       CONVERT(VARCHAR(250), NEWID()) AS Col1,
       CONVERT(VARCHAR(250), NEWID()) AS Col2,
       CONVERT(VARCHAR(250), NEWID()) AS Col3,
       CONVERT(VARCHAR(250), NEWID()) AS Col4,
       CONVERT(VARCHAR(250), NEWID()) AS Col5
  INTO CustomersTF2388
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 4)
GO
ALTER TABLE CustomersTF2388 ADD CONSTRAINT xpk_CustomersTF2388 PRIMARY KEY(CustomerID)
GO

SELECT * FROM CustomersTF2388
WHERE ContactName = 'Fabiano Amorim'
AND 1 = (SELECT 1)
GO

EXEC sp_helpstats CustomersTF2388
GO

DBCC SHOW_STATISTICS (CustomersTF2388, _WA_Sys_00000002_56B3DD81)
GO


/* Enabling TF2388 at session level to capture result of DBCC SHOW_STATISTICS with stats history info*/
DBCC TRACEON(2388) WITH NO_INFOMSGS;
DBCC SHOW_STATISTICS (CustomersTF2388, _WA_Sys_00000002_56B3DD81)
DBCC TRACEOFF(2388) WITH NO_INFOMSGS;
GO

UPDATE STATISTICS CustomersTF2388 _WA_Sys_00000002_56B3DD81
GO

DBCC TRACEON(2388) WITH NO_INFOMSGS;
DBCC SHOW_STATISTICS (CustomersTF2388, _WA_Sys_00000002_56B3DD81)
DBCC TRACEOFF(2388) WITH NO_INFOMSGS;
GO

INSERT INTO CustomersTF2388
(
  CustomerID,
  ContactName,
  Col1,
  Col2,
  Col3,
  Col4,
  Col5
)
VALUES
(
  0,    -- CustomerID - bigint
  NULL, -- ContactName - varchar(8)
  NULL, -- Col1 - varchar(250)
  NULL, -- Col2 - varchar(250)
  NULL, -- Col3 - varchar(250)
  NULL, -- Col4 - varchar(250)
  NULL  -- Col5 - varchar(250)
)
GO


UPDATE STATISTICS CustomersTF2388 _WA_Sys_00000002_56B3DD81
GO

DBCC TRACEON(2388) WITH NO_INFOMSGS;
DBCC SHOW_STATISTICS (CustomersTF2388, _WA_Sys_00000002_56B3DD81)
DBCC TRACEOFF(2388) WITH NO_INFOMSGS;
GO


-- Data about last 4 executions
UPDATE STATISTICS CustomersTF2388 _WA_Sys_00000002_56B3DD81
GO
DBCC TRACEON(2388) WITH NO_INFOMSGS;
DBCC SHOW_STATISTICS (CustomersTF2388, _WA_Sys_00000002_56B3DD81)
DBCC TRACEOFF(2388) WITH NO_INFOMSGS;
GO

-- Why is this useful? 
/*
- Did I had any update stats with no modifications? 
- What is the avg frequency a statistic get updated?
- Are rows being deleted and inserted, if so, are they really changing or it is almos the same?
- How many rows inserted per minute? (use the avg of minutes between each update and number of rows to calculate it)
- Is it number of steps/density too diff from last update? May indicate an update from Full to Sample...
- ...
*/