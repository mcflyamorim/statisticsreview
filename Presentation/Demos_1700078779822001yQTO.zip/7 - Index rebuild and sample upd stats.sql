/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Index rebuild and update stats
*/

USE Northwind
GO

-- Creating test table
-- 3 seconds to run
IF OBJECT_ID('CustomersBig') IS NOT NULL
  DROP TABLE CustomersBig
GO
SELECT TOP 1000000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS CustomerID, 
       SUBSTRING(CONVERT(VARCHAR(250),NEWID()),1,8) AS ContactName, 
       CONVERT(VARCHAR(250), NEWID()) AS Col1,
       CONVERT(VARCHAR(250), NEWID()) AS Col2,
       CONVERT(VARCHAR(250), NEWID()) AS Col3,
       CONVERT(VARCHAR(250), NEWID()) AS Col4
  INTO CustomersBig
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
ALTER TABLE CustomersBig ADD CONSTRAINT xpk_CustomersBig PRIMARY KEY(CustomerID)
GO
CREATE INDEX ixContactName ON CustomersBig(ContactName)
GO

-- Demo 1
-- When the index creation or rebuild operation is resumable, statistics are created or updated with the default sampling ratio.

-- Rebuild
ALTER INDEX ixContactName ON CustomersBig REBUILD
GO
-- Stat updated with fullscan
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('CustomersBig')
GO

-- Rebuild with RESUMABLE=ON
ALTER INDEX ixContactName on CustomersBig REBUILD WITH (ONLINE = ON, RESUMABLE = ON);
GO

-- Stat updated with sample
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('CustomersBig')
GO

-- Demo 2
-- When the index creation or rebuild operation is using a partitioned obj, 
-- statistics are created or updated with the default sampling ratio.

DROP INDEX IF EXISTS ixContactName ON CustomersBig
GO
IF OBJECT_ID('TabPartition') IS NOT NULL
  DROP TABLE TabPartition
GO
IF OBJECT_ID('TabPartitionElimination') IS NOT NULL
  DROP TABLE TabPartitionElimination
GO
IF EXISTS(SELECT * FROM sys.partition_schemes WHERE name = 'PartitionScheme1')
  DROP PARTITION SCHEME PartitionScheme1
GO
IF EXISTS(SELECT * FROM sys.partition_functions WHERE name = 'PartitionFunction1')
  DROP PARTITION FUNCTION PartitionFunction1
GO
CREATE PARTITION FUNCTION PartitionFunction1 (BIGINT)
AS RANGE FOR VALUES
(   1
);
CREATE PARTITION SCHEME PartitionScheme1 AS PARTITION PartitionFunction1 ALL TO ([PRIMARY]);
GO

-- Applying partitioning on ixContactName
CREATE INDEX ixContactName ON CustomersBig(ContactName, CustomerID) 
ON PartitionScheme1 (CustomerID);
GO

ALTER INDEX ixContactName ON CustomersBig REBUILD
GO

-- Stat updated with sample
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('CustomersBig')
GO


-- Demo 3
-- ALTER INDEX ALL REBUILD does not update auto created or manually created stats 

;WITH CTE_1
AS
(
SELECT DISTINCT Col1, Col2, Col3 FROM CustomersBig
)
SELECT TOP 1 * FROM CTE_1
GO

CREATE STATISTICS StatsCol4 ON CustomersBig(Col4)
GO

-- Distinct will trigger auto create stats for all referenced columns...
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('CustomersBig')
GO

ALTER INDEX ALL ON CustomersBig REBUILD
GO

-- Auto and user created stats were not updated by the ALTER INDEX ALL REBUILD
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('CustomersBig')
GO
