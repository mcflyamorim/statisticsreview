/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  TF2371 and DB compatibility level
*/

USE Northwind
GO

SELECT objname,
       statsname,
       unfiltered_rows,
       tab1.auto_update_threshold_type,
       tab1.auto_update_threshold
FROM (SELECT OBJECT_NAME(a.object_id) AS objname,
             a.name AS statsname,
             sp.unfiltered_rows
      FROM sys.stats AS a
      CROSS APPLY sys.dm_db_stats_properties(a.object_id, a.stats_id) AS sp ) AS a
CROSS APPLY (SELECT CASE
                      WHEN (SELECT compatibility_level
                            FROM sys.databases
                            WHERE QUOTENAME(name) = QUOTENAME(DB_NAME())) >= 130
                           AND COALESCE(a.unfiltered_rows, 0) >= 25001 THEN 'Dynamic'
                      ELSE 'Static'
                    END,
                    CASE
                      WHEN (SELECT compatibility_level
                            FROM sys.databases
                            WHERE QUOTENAME(name) = QUOTENAME(DB_NAME())) >= 130
                           AND COALESCE(a.unfiltered_rows, 0) >= 25001 THEN
                        CONVERT(BIGINT, SQRT(1000 * COALESCE(a.unfiltered_rows, 0)))
                      ELSE (CASE
                              WHEN COALESCE(a.unfiltered_rows, 0) IS NULL THEN 0
                              WHEN COALESCE(a.unfiltered_rows, 0) <= 500 THEN 501
                              ELSE 500 + CONVERT(BIGINT, COALESCE(a.unfiltered_rows, 0) * 0.2)
                            END)
                    END) AS tab1(auto_update_threshold_type, auto_update_threshold)
ORDER BY unfiltered_rows DESC;

/*
The Query Optimizer determines when statistics might be out-of-date by counting the number of row modifications since 
the last statistics update and comparing the number of row modifications to a threshold. The threshold is based on the 
table cardinality, which can be defined as the number of rows in the table or indexed view. Up to SQL Server 2014 (12.x), 
the Database Engine uses a recompilation threshold based on the number of rows in the table or indexed view at the time statistics were evaluated. 
Starting with SQL Server 2016 (13.x) and under the database compatibility level 130, the Database Engine also uses a 
decreasing, dynamic statistics recompilation threshold that adjusts according to the table cardinality at the time 
statistics were evaluated. With this change, statistics on large tables will be updated more frequently. 
However, if a database has a compatibility level below 130, then the SQL Server 2014 (12.x) thresholds apply.


In SQL Server 2008 R2 through SQL Server 2014 (12.x), or in SQL Server 2016 (13.x) and later builds, 
if you have databases under compatibility level 120 and lower, you'll need to enable trace flag 2371 
to make SQL Server uses a decreasing, dynamic statistics update threshold.

- If you have databases under compatibility level 120 and lower, you still need to enable TF2371, even on SQL Server 2016 and newer builds.
- For a large majority of SQL Server installations, it is a best practice to enable TF2371.
*/