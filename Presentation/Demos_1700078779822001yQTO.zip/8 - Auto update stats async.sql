/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Auto update stats async
*/

USE Northwind
GO

/*
-- 2 minutes to run
DROP TABLE IF EXISTS Customers_Async_1, Customers_Async_2, Customers_Async_3, 
                     Customers_Async_4, Customers_Async_5, Customers_Async_6, 
                     Customers_Async_7, Customers_Async_8, Customers_Async_9, 
                     Customers_Async_10
GO
SELECT TOP 5000000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS CustomerID, 
       SUBSTRING(CONVERT(VARCHAR(250),NEWID()),1,8) AS ContactName, 
       CONVERT(VARCHAR(250), NEWID()) AS Col1,
       CONVERT(VARCHAR(250), NEWID()) AS Col2,
       CONVERT(VARCHAR(250), NEWID()) AS Col3,
       CONVERT(VARCHAR(250), NEWID()) AS Col4,
       CONVERT(VARCHAR(250), NEWID()) AS Col5
  INTO Customers_Async_1
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 4)
GO
ALTER TABLE Customers_Async_1 ADD CONSTRAINT xpk_Customers_Async_1 PRIMARY KEY(CustomerID)
GO

SELECT * INTO Customers_Async_2 FROM Customers_Async_1
SELECT * INTO Customers_Async_3 FROM Customers_Async_1
SELECT * INTO Customers_Async_4 FROM Customers_Async_1
SELECT * INTO Customers_Async_5 FROM Customers_Async_1
SELECT * INTO Customers_Async_6 FROM Customers_Async_1
SELECT * INTO Customers_Async_7 FROM Customers_Async_1
SELECT * INTO Customers_Async_8 FROM Customers_Async_1
SELECT * INTO Customers_Async_9 FROM Customers_Async_1
SELECT * INTO Customers_Async_10 FROM Customers_Async_1
GO
ALTER TABLE Customers_Async_2 ADD CONSTRAINT xpk_Customers_Async_2 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_3 ADD CONSTRAINT xpk_Customers_Async_3 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_4 ADD CONSTRAINT xpk_Customers_Async_4 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_5 ADD CONSTRAINT xpk_Customers_Async_5 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_6 ADD CONSTRAINT xpk_Customers_Async_6 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_7 ADD CONSTRAINT xpk_Customers_Async_7 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_8 ADD CONSTRAINT xpk_Customers_Async_8 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_9 ADD CONSTRAINT xpk_Customers_Async_9 PRIMARY KEY(CustomerID)
ALTER TABLE Customers_Async_10 ADD CONSTRAINT xpk_Customers_Async_10 PRIMARY KEY(CustomerID)
GO
CREATE STATISTICS Stats_Col1 ON Customers_Async_1(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_2(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_3(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_4(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_5(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_6(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_7(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_8(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_9(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col1 ON Customers_Async_10(Col1) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
GO
CREATE STATISTICS Stats_Col2 ON Customers_Async_1(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_2(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_3(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_4(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_5(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_6(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_7(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_8(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_9(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col2 ON Customers_Async_10(Col2) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
GO
CREATE STATISTICS Stats_Col3 ON Customers_Async_1(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_2(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_3(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_4(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_5(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_6(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_7(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_8(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_9(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
CREATE STATISTICS Stats_Col3 ON Customers_Async_10(Col3) WITH SAMPLE 100 PERCENT, PERSIST_SAMPLE_PERCENT = ON
GO

ALTER DATABASE Northwind SET AUTO_UPDATE_STATISTICS_ASYNC ON
GO
*/

-- Set all stats as modified
BEGIN TRAN
TRUNCATE TABLE Customers_Async_1
TRUNCATE TABLE Customers_Async_2
TRUNCATE TABLE Customers_Async_3
TRUNCATE TABLE Customers_Async_4
TRUNCATE TABLE Customers_Async_5
TRUNCATE TABLE Customers_Async_6
TRUNCATE TABLE Customers_Async_7
TRUNCATE TABLE Customers_Async_8
TRUNCATE TABLE Customers_Async_9
TRUNCATE TABLE Customers_Async_10
ROLLBACK TRAN
GO

-- All rows were modified
SELECT OBJECT_NAME(sp.object_id) AS objName, sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id IN (OBJECT_ID('Customers_Async_1'), 
                         OBJECT_ID('Customers_Async_2'), 
                         OBJECT_ID('Customers_Async_3'), 
                         OBJECT_ID('Customers_Async_4'), 
                         OBJECT_ID('Customers_Async_5'),
                         OBJECT_ID('Customers_Async_6'), 
                         OBJECT_ID('Customers_Async_7'), 
                         OBJECT_ID('Customers_Async_8'), 
                         OBJECT_ID('Customers_Async_9'), 
                         OBJECT_ID('Customers_Async_10'));
GO

-- This will add several jobs on async pending list...
-- Look at CPU usage (perfmon) while updates are running...
SELECT DISTINCT TOP 100 Customers_Async_1.Col1, Customers_Async_1.Col2, Customers_Async_1.Col3,
Customers_Async_2.Col1, Customers_Async_2.Col2, Customers_Async_2.Col3,
Customers_Async_3.Col1, Customers_Async_3.Col2, Customers_Async_3.Col3,
Customers_Async_4.Col1, Customers_Async_4.Col2, Customers_Async_4.Col3,
Customers_Async_5.Col1, Customers_Async_5.Col2, Customers_Async_5.Col3,
Customers_Async_6.Col1, Customers_Async_6.Col2, Customers_Async_6.Col3,
Customers_Async_7.Col1, Customers_Async_7.Col2, Customers_Async_7.Col3,
Customers_Async_8.Col1, Customers_Async_8.Col2, Customers_Async_8.Col3,
Customers_Async_9.Col1, Customers_Async_9.Col2, Customers_Async_9.Col3,
Customers_Async_10.Col1, Customers_Async_10.Col2, Customers_Async_10.Col3
FROM Customers_Async_1
INNER JOIN Customers_Async_2 ON Customers_Async_2.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_3 ON Customers_Async_3.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_4 ON Customers_Async_4.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_5 ON Customers_Async_5.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_6 ON Customers_Async_6.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_7 ON Customers_Async_7.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_8 ON Customers_Async_8.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_9 ON Customers_Async_9.CustomerID = Customers_Async_1.CustomerID
INNER JOIN Customers_Async_10 ON Customers_Async_10.CustomerID = Customers_Async_1.CustomerID
WHERE Customers_Async_1.CustomerID <= 100
OPTION (RECOMPILE, MAXDOP 1)
GO

-- SET update async back to OFF
ALTER DATABASE Northwind SET AUTO_UPDATE_STATISTICS_ASYNC OFF
GO


/*

You can view currently queued jobs via the sys.dm_exec_background_job_queue dynamic management view, 
which is currently used only for async update statistics jobs. The database_id column tells you what 
database the job will run it, while the object_id1 column displays the object ID of the table or view, 
and the object_id2 column displays the statistics ID that is to be updated.
The system will create up to two workers per SOS scheduler (with a fixed maximum of eight workers) 
to process jobs from the queue. 
If we haven't reached the limit when a new request is enqueued, then the job starts executing 
immediately on a background worker. Otherwise, it waits for an available worker.
The job queue is limited to, at most, 100 requests.

-- Monitor job execution

USE master
GO
SELECT OBJECT_NAME(dm_exec_background_job_queue.[object_id1], dm_exec_background_job_queue.database_id) AS [object_name],
       dm_exec_background_job_queue.*,
       dm_exec_requests.command,
	      dm_exec_requests.cpu_time, 
	      dm_exec_requests.reads, 
	      dm_exec_requests.writes, 
	      dm_exec_requests.logical_reads, 
	      dm_exec_requests.granted_query_memory,
	      dm_exec_requests.last_wait_type
FROM sys.dm_exec_background_job_queue
    LEFT OUTER JOIN sys.dm_exec_requests
        ON dm_exec_requests.session_id = dm_exec_background_job_queue.session_id
*/