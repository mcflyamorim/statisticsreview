/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Filtered statistics
*/

USE Northwind
GO

-- Creating test table
-- 2 seconds to run
IF OBJECT_ID('CustomersFiltered') IS NOT NULL
  DROP TABLE CustomersFiltered
GO
SELECT TOP 200000
       ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT 1)),0) AS CustomerID, 
       SUBSTRING(CONVERT(VARCHAR(250),NEWID()),1,8) AS ContactName, 
       CONVERT(VARCHAR(250), NEWID()) AS Col1,
       CONVERT(VARCHAR(250), NEWID()) AS Col2,
       CONVERT(VARCHAR(250), NEWID()) AS Col3,
       CONVERT(VARCHAR(250), 'Enabled') AS Col4,
       CONVERT(VARCHAR(250), NULL) AS Col5
  INTO CustomersFiltered
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
OPTION (MAXDOP 8)
GO
ALTER TABLE CustomersFiltered ADD CONSTRAINT xpk_CustomersFiltered PRIMARY KEY(CustomerID)
GO
UPDATE TOP (5) CustomersFiltered SET Col4 = 'Disabled'
GO

-- Bad estimation because of auto create stat
SELECT * FROM CustomersFiltered 
WHERE Col4 = 'Disabled'
ORDER BY Col3
OPTION (RECOMPILE, QUERYTRACEON 9130)
GO

-- Auto create stat on Col4
SELECT sp.stats_id, stat.name AS statname, c.name AS colname, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
INNER JOIN sys.stats_columns AS stat_cols
ON stat_cols.object_id = stat.object_id
AND stat_cols.stats_id = stat.stats_id
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
INNER JOIN sys.columns AS c
ON c.object_id = stat.object_id
AND stat_cols.column_id = c.column_id
WHERE stat.object_id = object_id('CustomersFiltered')
GO

DBCC SHOW_STATISTICS(CustomersFiltered, _WA_Sys_00000006_1A9EF37A)
GO

UPDATE STATISTICS CustomersFiltered _WA_Sys_00000006_1A9EF37A WITH FULLSCAN
GO

DBCC SHOW_STATISTICS(CustomersFiltered, _WA_Sys_00000006_1A9EF37A)
GO

-- Better estimation with fullscan
SELECT * FROM CustomersFiltered 
WHERE Col4 = 'Disabled'
ORDER BY Col3
OPTION (RECOMPILE, QUERYTRACEON 9130)
GO

-- Set stat back to sample...
UPDATE STATISTICS CustomersFiltered _WA_Sys_00000006_1A9EF37A WITH SAMPLE
GO

-- Creating a filtered index to help
DROP INDEX IF EXISTS ixContactName ON CustomersFiltered
GO
CREATE INDEX ixContactName ON CustomersFiltered(ContactName)
WHERE Col4 = 'Disabled'
GO

-- Good estimate using filtered index
SELECT * FROM CustomersFiltered 
WHERE Col4 = 'Disabled'
ORDER BY Col3
OPTION (RECOMPILE, QUERYTRACEON 9130)
GO

DBCC SHOW_STATISTICS(CustomersFiltered, ixContactName)
GO

-- What if I change lot of data on table?
UPDATE TOP (50000) CustomersFiltered SET Col4 = 'Disabled'
WHERE Col4 = 'Enabled'
GO


-- Auto create stat show the modification counter, but the filtered doesn't
SELECT sp.stats_id, stat.name AS statname, c.name AS colname, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
INNER JOIN sys.stats_columns AS stat_cols
ON stat_cols.object_id = stat.object_id
AND stat_cols.stats_id = stat.stats_id
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
INNER JOIN sys.columns AS c
ON c.object_id = stat.object_id
AND stat_cols.column_id = c.column_id
WHERE stat.object_id = object_id('CustomersFiltered')
GO


-- What will be the estimate now?
-- Ops... 
SELECT * FROM CustomersFiltered 
WHERE Col4 = 'Disabled'
ORDER BY Col3
OPTION (RECOMPILE, QUERYTRACEON 9130)
GO


-- Auto update was triggered on auto created stat, but QO is still using
-- the outdated filtered stat...  :-(
SELECT sp.stats_id, stat.name AS statname, c.name AS colname, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
INNER JOIN sys.stats_columns AS stat_cols
ON stat_cols.object_id = stat.object_id
AND stat_cols.stats_id = stat.stats_id
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
INNER JOIN sys.columns AS c
ON c.object_id = stat.object_id
AND stat_cols.column_id = c.column_id
WHERE stat.object_id = object_id('CustomersFiltered')
GO

