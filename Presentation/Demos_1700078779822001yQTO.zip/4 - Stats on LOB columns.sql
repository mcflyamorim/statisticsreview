/*
  PASS Summit 2023 - 13 Optimizer Statistic Problems you Didn�t Know you Had
  Fabiano Amorim - fabianonevesamorim@hotmail.com

  Stats on LOB columns
  Check if there are statistics on LOB columns. 
  The LOBs (Large Objects) can be broadly classified as Character Large Objects (CLOBs) or Binary Large Objects (BLOBs).
  Tables that are smaller than 8MB (1024 pages) are always fully scanned to update/create statistics. 
  But, SQL only consider in-row data, that is, all data types except LOB data types. 
  Because the number of LOB pages is not directly considered the sample percentage remain a large value 
  and the first and last 100 bytes are retrieved it can trigger a large LOB scan operation.
*/

USE Northwind
GO
/*
IF OBJECT_ID('Customers_LobCol') IS NOT NULL
  DROP TABLE Customers_LobCol
GO
-- 25 seconds to run
SELECT TOP 150000
       ISNULL(CONVERT(INT, ROW_NUMBER() OVER(ORDER BY (SELECT 1))),0) AS CustomerID,
       'Info - ' + ISNULL(CONVERT(VARCHAR(MAX),REPLICATE(CONVERT(VARBINARY(MAX), CONVERT(VARCHAR(250), NEWID())), 2000)), '') AS Info
  INTO Customers_LobCol
  FROM master.dbo.spt_values A
 CROSS JOIN master.dbo.spt_values B
 CROSS JOIN master.dbo.spt_values C
 CROSS JOIN master.dbo.spt_values D
 CROSS APPLY (SELECT CRYPT_GEN_RANDOM (10)) AS t1(ContactName)
 CROSS APPLY (SELECT CRYPT_GEN_RANDOM (15)) AS t2(CompanyName)
 CROSS APPLY (SELECT REPLACE(REPLACE(REPLACE(CONVERT(XML, '').value('xs:base64Binary(sql:column("t1.ContactName"))', 'VARCHAR(MAX)'), '=', ''), '/', ''), '+', '')) AS t3(ContactName)
 CROSS APPLY (SELECT REPLACE(REPLACE(REPLACE(CONVERT(XML, '').value('xs:base64Binary(sql:column("t2.CompanyName"))', 'VARCHAR(MAX)'), '=', ''), '/', ''), '+', '')) AS t4(ColumnToShowIssueWithCCC)
OPTION (MAXDOP 4)
GO
*/

SELECT 12006312 / 1024. / 1024.
-- 12006312 KB -- 11.45 GB
sp_spaceused Customers_LobCol
GO

SELECT 
   OBJECT_NAME(p.object_id) AS TabName, 
   p.rows,
   au.type_desc,
   au.total_pages, au.used_pages, au.data_pages,
   p.data_compression_desc, p.index_id, 
   fg.name, fg.type_desc
FROM sys.allocation_units AS au WITH(NOLOCK)
JOIN sys.partitions p WITH(NOLOCK) ON au.container_id = p.partition_id
JOIN sys.filegroups AS fg ON fg.data_space_id = au.data_space_id
WHERE OBJECT_NAME(p.object_id) = 'Customers_LobCol'
GO


-- This will trigger auto_create_stats and create
-- a stats on Info column
-- auto create on column Info will take forever(14sec), because 
-- create stats on LOB data is very slow and 
-- SQL will do a fullscan stat as the table has less than 
-- 1024 pages IN_ROW_DATA pages...
SELECT COUNT(*) AS Cnt
  FROM Customers_LobCol
 WHERE Info LIKE 'Info - Test%'
   AND 1 = (SELECT 1)
GO
/*
SELECT StatMan([SC0], [LC0])
FROM (SELECT TOP 100 PERCENT
             CONVERT(
               [varchar](200),
               SUBSTRING([Info], 1, 100)
               + +substring([Info], case when LEN([Info]) <= 200 then 101 else LEN([Info]) - 99 end, 100)) AS [SC0],
             datalength([Info]) AS [LC0]
      FROM [dbo].[Customers_LobCol] WITH (READUNCOMMITTED)
      ORDER BY [SC0]) AS _MS_UPDSTATS_TBL
OPTION (MAXDOP 8);
*/

-- auto created stat on Info
SELECT sp.stats_id, name, filter_definition, last_updated, rows, rows_sampled, steps, unfiltered_rows, modification_counter   
FROM sys.stats AS stat   
CROSS APPLY sys.dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp  
WHERE stat.object_id = object_id('Customers_LobCol');
GO


DROP STATISTICS Customers_LobCol._WA_Sys_00000002_6DCC4D03
GO

CREATE STATISTICS Stat1_Info ON Customers_LobCol(Info) 
WITH NORECOMPUTE, SAMPLE 0 PERCENT
GO

SELECT COUNT(*) AS Cnt
  FROM Customers_LobCol
 WHERE Info LIKE 'Info - Test%'
   AND 1 = (SELECT 1)
GO